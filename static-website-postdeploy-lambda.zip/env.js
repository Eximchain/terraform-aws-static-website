"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
// Provided automagically by AWS
exports.awsRegion = process.env.AWS_REGION;
// Provided by Terraform
exports.websiteContentBucket = process.env.WEBSITE_CONTENT_BUCKET;
var aws_sdk_1 = __importDefault(require("aws-sdk"));
exports.AWS = aws_sdk_1.default;
exports.AWS.config.update({ region: exports.awsRegion });
exports.default = {
    AWS: exports.AWS, awsRegion: exports.awsRegion
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZW52LmpzIiwic291cmNlUm9vdCI6InNyYy8iLCJzb3VyY2VzIjpbImVudi50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7OztBQUFBLGdDQUFnQztBQUNuQixRQUFBLFNBQVMsR0FBRyxPQUFPLENBQUMsR0FBRyxDQUFDLFVBQW9CLENBQUM7QUFFMUQsd0JBQXdCO0FBQ1gsUUFBQSxvQkFBb0IsR0FBRyxPQUFPLENBQUMsR0FBRyxDQUFDLHNCQUFnQyxDQUFDO0FBR2pGLG9EQUFzQztBQUN6QixRQUFBLEdBQUcsR0FBRyxpQkFBZSxDQUFDO0FBQ25DLFdBQUcsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLEVBQUMsTUFBTSxFQUFFLGlCQUFTLEVBQUMsQ0FBQyxDQUFDO0FBRXZDLGtCQUFlO0lBQ1gsR0FBRyxhQUFBLEVBQUUsU0FBUyxtQkFBQTtDQUNqQixDQUFDIn0=