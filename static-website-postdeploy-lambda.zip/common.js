"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.defaultTags = [
    {
        Key: "Application",
        Value: "DappBot"
    },
    {
        Key: "ManagedBy",
        Value: "DappBot"
    }
];
/*
Returns a Promise that rejects with reason after msDelay milliseconds
*/
function rejectDelay(reason) {
    var msDelay = 700;
    return new Promise(function (resolve, reject) {
        setTimeout(reject.bind(null, reason), msDelay);
    });
}
exports.rejectDelay = rejectDelay;
/*
Retries a promise returned by promiseGenerator up to maxRetries times as long as the error is retryable
Based on https://stackoverflow.com/questions/38213668/promise-retry-design-patterns
*/
function addAwsPromiseRetries(promiseGenerator, maxRetries) {
    // Ensure we call promiseGenerator on the first iteration
    var p = Promise.reject({ retryable: true });
    /*
    Appends maxRetries number of retry and delay promises to an AWS promise, returning once a retry promise resolves.

    1. As long as promiseGenerator() rejects with a retryable error, we retry and then delay before the next loop iteration
    2. If promiseGenerator() resolves, the rest of the loop will finish without triggering any further catch functions
    3. If promiseGenerator() rejects with a non-retryable error, the rest of the loop will finish without any further
       retries or delays since all catch blocks will simply return Promise.reject(err)
    */
    for (var i = 0; i < maxRetries; i++) {
        // @ts-ignore TS doesn't like that these could technically reject with
        // an error.  Rather than force (* as ReturnType) every place we await
        // this, just have the compiler assume this function succeeds.
        p = p.catch(function (err) { return err.retryable ? promiseGenerator() : Promise.reject(err); })
            .catch(function (err) { return err.retryable ? rejectDelay(err) : Promise.reject(err); });
    }
    return p;
}
exports.addAwsPromiseRetries = addAwsPromiseRetries;
exports.default = {
    defaultTags: exports.defaultTags, addAwsPromiseRetries: addAwsPromiseRetries
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY29tbW9uLmpzIiwic291cmNlUm9vdCI6InNyYy8iLCJzb3VyY2VzIjpbImNvbW1vbi50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOztBQUthLFFBQUEsV0FBVyxHQUFpQjtJQUNyQztRQUNJLEdBQUcsRUFBRSxhQUFhO1FBQ2xCLEtBQUssRUFBRSxTQUFTO0tBQ25CO0lBQ0Q7UUFDSSxHQUFHLEVBQUUsV0FBVztRQUNoQixLQUFLLEVBQUUsU0FBUztLQUNuQjtDQUNKLENBQUM7QUFFRjs7RUFFRTtBQUNGLFNBQWdCLFdBQVcsQ0FBQyxNQUFhO0lBQ3JDLElBQUksT0FBTyxHQUFHLEdBQUcsQ0FBQztJQUNsQixPQUFPLElBQUksT0FBTyxDQUFDLFVBQVMsT0FBTyxFQUFFLE1BQU07UUFDdkMsVUFBVSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSSxFQUFFLE1BQU0sQ0FBQyxFQUFFLE9BQU8sQ0FBQyxDQUFDO0lBQ25ELENBQUMsQ0FBQyxDQUFDO0FBQ1AsQ0FBQztBQUxELGtDQUtDO0FBRUQ7OztFQUdFO0FBQ0YsU0FBZ0Isb0JBQW9CLENBQWEsZ0JBQXdDLEVBQUUsVUFBaUI7SUFDeEcseURBQXlEO0lBQ3pELElBQUksQ0FBQyxHQUF1QixPQUFPLENBQUMsTUFBTSxDQUFDLEVBQUMsU0FBUyxFQUFFLElBQUksRUFBQyxDQUFDLENBQUM7SUFFOUQ7Ozs7Ozs7TUFPRTtJQUNGLEtBQUksSUFBSSxDQUFDLEdBQUMsQ0FBQyxFQUFFLENBQUMsR0FBQyxVQUFVLEVBQUUsQ0FBQyxFQUFFLEVBQUU7UUFDNUIsc0VBQXNFO1FBQ3RFLHNFQUFzRTtRQUN0RSw4REFBOEQ7UUFDOUQsQ0FBQyxHQUFHLENBQUMsQ0FBQyxLQUFLLENBQUMsVUFBQSxHQUFHLElBQUksT0FBQSxHQUFHLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxFQUF4RCxDQUF3RCxDQUFDO2FBQ3RFLEtBQUssQ0FBQyxVQUFBLEdBQUcsSUFBSSxPQUFBLEdBQUcsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsRUFBdEQsQ0FBc0QsQ0FBQyxDQUFDO0tBQzlFO0lBQ0QsT0FBTyxDQUFDLENBQUM7QUFDYixDQUFDO0FBcEJELG9EQW9CQztBQUVELGtCQUFlO0lBQ1gsV0FBVyxxQkFBQSxFQUFFLG9CQUFvQixzQkFBQTtDQUNwQyxDQUFDIn0=