"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
// @ts-ignore Alas, there are no published bindings for node-zip.
var node_zip_1 = __importDefault(require("node-zip"));
var common_1 = require("../common");
var env_1 = require("../env");
var s3 = new env_1.AWS.S3({ apiVersion: '2006-03-01' });
function promiseEnableS3BucketCORS(bucketName, dappDNS) {
    var maxRetries = 5;
    var params = {
        Bucket: bucketName,
        CORSConfiguration: {
            CORSRules: [
                {
                    "AllowedHeaders": ["Authorization"],
                    "AllowedOrigins": ["https://" + dappDNS],
                    "AllowedMethods": ["GET"],
                    MaxAgeSeconds: 3000
                }
            ]
        }
    };
    return common_1.addAwsPromiseRetries(function () { return s3.putBucketCors(params).promise(); }, maxRetries);
}
function promiseMakeObjectNoCache(bucketName, objectKey) {
    return __awaiter(this, void 0, void 0, function () {
        var maxRetries, indexObject, putParams;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    maxRetries = 5;
                    return [4 /*yield*/, promiseGetS3Object(bucketName, objectKey)];
                case 1:
                    indexObject = _a.sent();
                    putParams = {
                        Bucket: bucketName,
                        ACL: 'public-read',
                        ContentType: indexObject.ContentType,
                        Key: objectKey,
                        Body: indexObject.Body,
                        CacheControl: 'max-age=0,no-cache,no-store,must-revalidate'
                    };
                    return [2 /*return*/, common_1.addAwsPromiseRetries(function () { return s3.putObject(putParams).promise(); }, maxRetries)];
            }
        });
    });
}
function promiseGetS3Object(bucketName, objectKey) {
    var maxRetries = 5;
    var params = {
        Bucket: bucketName,
        Key: objectKey
    };
    return common_1.addAwsPromiseRetries(function () { return s3.getObject(params).promise(); }, maxRetries);
}
function promiseGetS3ObjectWithCredentials(bucketName, objectKey, credentials) {
    var maxRetries = 5;
    var params = {
        Bucket: bucketName,
        Key: objectKey
    };
    var credentialClient = new env_1.AWS.S3({ apiVersion: '2006-03-01', credentials: credentials });
    return common_1.addAwsPromiseRetries(function () { return credentialClient.getObject(params).promise(); }, maxRetries);
}
function downloadArtifact(artifactLocation, artifactCredentials) {
    return __awaiter(this, void 0, void 0, function () {
        var getObjectResult, zipArtifact;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0: return [4 /*yield*/, promiseGetS3ObjectWithCredentials(artifactLocation.bucketName, artifactLocation.objectKey, artifactCredentials)];
                case 1:
                    getObjectResult = _a.sent();
                    console.log("Successfully retrieved artifact: ", getObjectResult);
                    zipArtifact = node_zip_1.default(getObjectResult.Body, { base64: false, checkCRC32: true });
                    console.log("Loaded Zip Artifact");
                    return [2 /*return*/, zipArtifact];
            }
        });
    });
}
exports.default = {
    getObject: promiseGetS3Object,
    makeObjectNoCache: promiseMakeObjectNoCache,
    enableBucketCors: promiseEnableS3BucketCORS,
    downloadArtifact: downloadArtifact
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiczMuanMiLCJzb3VyY2VSb290Ijoic3JjLyIsInNvdXJjZXMiOlsic2VydmljZXMvczMudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBLGlFQUFpRTtBQUNqRSxzREFBMkI7QUFDM0Isb0NBQWlEO0FBQ2pELDhCQUE2QjtBQUU3QixJQUFNLEVBQUUsR0FBRyxJQUFJLFNBQUcsQ0FBQyxFQUFFLENBQUMsRUFBQyxVQUFVLEVBQUUsWUFBWSxFQUFDLENBQUMsQ0FBQztBQUVsRCxTQUFTLHlCQUF5QixDQUFDLFVBQWlCLEVBQUUsT0FBYztJQUNoRSxJQUFJLFVBQVUsR0FBRyxDQUFDLENBQUM7SUFDbkIsSUFBSSxNQUFNLEdBQUc7UUFDVCxNQUFNLEVBQUcsVUFBVTtRQUNuQixpQkFBaUIsRUFBRztZQUNoQixTQUFTLEVBQUc7Z0JBQ1I7b0JBQ0ksZ0JBQWdCLEVBQUUsQ0FBQyxlQUFlLENBQUM7b0JBQ25DLGdCQUFnQixFQUFFLENBQUMsYUFBVyxPQUFTLENBQUM7b0JBQ3hDLGdCQUFnQixFQUFFLENBQUMsS0FBSyxDQUFDO29CQUN6QixhQUFhLEVBQUssSUFBSTtpQkFDekI7YUFDSjtTQUNKO0tBQ0osQ0FBQTtJQUNELE9BQU8sNkJBQW9CLENBQUMsY0FBTSxPQUFBLEVBQUUsQ0FBQyxhQUFhLENBQUMsTUFBTSxDQUFDLENBQUMsT0FBTyxFQUFFLEVBQWxDLENBQWtDLEVBQUUsVUFBVSxDQUFDLENBQUM7QUFDdEYsQ0FBQztBQUVELFNBQWUsd0JBQXdCLENBQUMsVUFBaUIsRUFBRSxTQUFnQjs7Ozs7O29CQUNuRSxVQUFVLEdBQUcsQ0FBQyxDQUFDO29CQUNDLHFCQUFNLGtCQUFrQixDQUFDLFVBQVUsRUFBRSxTQUFTLENBQUMsRUFBQTs7b0JBQTdELFdBQVcsR0FBRyxTQUErQztvQkFDN0QsU0FBUyxHQUFHO3dCQUNkLE1BQU0sRUFBRyxVQUFVO3dCQUNuQixHQUFHLEVBQUcsYUFBYTt3QkFDbkIsV0FBVyxFQUFFLFdBQVcsQ0FBQyxXQUFXO3dCQUNwQyxHQUFHLEVBQUcsU0FBUzt3QkFDZixJQUFJLEVBQUcsV0FBVyxDQUFDLElBQUk7d0JBQ3ZCLFlBQVksRUFBRSw2Q0FBNkM7cUJBQzlELENBQUE7b0JBQ0Qsc0JBQU8sNkJBQW9CLENBQUMsY0FBTSxPQUFBLEVBQUUsQ0FBQyxTQUFTLENBQUMsU0FBUyxDQUFDLENBQUMsT0FBTyxFQUFFLEVBQWpDLENBQWlDLEVBQUUsVUFBVSxDQUFDLEVBQUM7Ozs7Q0FDcEY7QUFFRCxTQUFTLGtCQUFrQixDQUFDLFVBQWlCLEVBQUUsU0FBZ0I7SUFDM0QsSUFBSSxVQUFVLEdBQUcsQ0FBQyxDQUFDO0lBQ25CLElBQU0sTUFBTSxHQUFHO1FBQ1gsTUFBTSxFQUFHLFVBQVU7UUFDbkIsR0FBRyxFQUFHLFNBQVM7S0FDbEIsQ0FBQTtJQUNELE9BQU8sNkJBQW9CLENBQUMsY0FBTSxPQUFBLEVBQUUsQ0FBQyxTQUFTLENBQUMsTUFBTSxDQUFDLENBQUMsT0FBTyxFQUFFLEVBQTlCLENBQThCLEVBQUUsVUFBVSxDQUFDLENBQUM7QUFDbEYsQ0FBQztBQUVELFNBQVMsaUNBQWlDLENBQUMsVUFBaUIsRUFBRSxTQUFnQixFQUFFLFdBQXVCO0lBQ25HLElBQUksVUFBVSxHQUFHLENBQUMsQ0FBQztJQUNuQixJQUFNLE1BQU0sR0FBRztRQUNYLE1BQU0sRUFBRyxVQUFVO1FBQ25CLEdBQUcsRUFBRyxTQUFTO0tBQ2xCLENBQUE7SUFFRCxJQUFJLGdCQUFnQixHQUFHLElBQUksU0FBRyxDQUFDLEVBQUUsQ0FBQyxFQUFDLFVBQVUsRUFBRSxZQUFZLEVBQUUsV0FBVyxFQUFFLFdBQVcsRUFBQyxDQUFDLENBQUM7SUFFeEYsT0FBTyw2QkFBb0IsQ0FBQyxjQUFNLE9BQUEsZ0JBQWdCLENBQUMsU0FBUyxDQUFDLE1BQU0sQ0FBQyxDQUFDLE9BQU8sRUFBRSxFQUE1QyxDQUE0QyxFQUFFLFVBQVUsQ0FBQyxDQUFDO0FBQ2hHLENBQUM7QUFFRCxTQUFlLGdCQUFnQixDQUFDLGdCQUFtQyxFQUFFLG1CQUErQjs7Ozs7d0JBQzFFLHFCQUFNLGlDQUFpQyxDQUFDLGdCQUFnQixDQUFDLFVBQVUsRUFBRSxnQkFBZ0IsQ0FBQyxTQUFTLEVBQUUsbUJBQW1CLENBQUMsRUFBQTs7b0JBQXZJLGVBQWUsR0FBRyxTQUFxSDtvQkFDM0ksT0FBTyxDQUFDLEdBQUcsQ0FBQyxtQ0FBbUMsRUFBRSxlQUFlLENBQUMsQ0FBQztvQkFFOUQsV0FBVyxHQUFHLGtCQUFHLENBQUMsZUFBZSxDQUFDLElBQUksRUFBRSxFQUFDLE1BQU0sRUFBRSxLQUFLLEVBQUUsVUFBVSxFQUFFLElBQUksRUFBQyxDQUFDLENBQUM7b0JBQy9FLE9BQU8sQ0FBQyxHQUFHLENBQUMscUJBQXFCLENBQUMsQ0FBQztvQkFFbkMsc0JBQU8sV0FBVyxFQUFDOzs7O0NBQ3RCO0FBRUQsa0JBQWU7SUFDWCxTQUFTLEVBQUcsa0JBQWtCO0lBQzlCLGlCQUFpQixFQUFHLHdCQUF3QjtJQUM1QyxnQkFBZ0IsRUFBRyx5QkFBeUI7SUFDNUMsZ0JBQWdCLEVBQUcsZ0JBQWdCO0NBQ3RDLENBQUEifQ==